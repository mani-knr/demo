import "./App.css";
import { Counter } from "./components/Counter";

function App() {
  return (
    <div className="counter">
      <Counter />
    </div>
  );
}

export default App;
