import "./App.css";
import { CardGame } from "./components/CardGame";
function App() {
  return (
    <div>
      <CardGame />
    </div>
  );
}

export default App;
