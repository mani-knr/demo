import React from "react";
export const UpperCard = () => {
  return (
    <div className="upper-card">
      <i className={"fa-solid fa-star premium"}></i>
      <img src={"./itachi.jpg"} alt="Failed to load" />
      <h4>{"Film Director,Producer"}</h4>
      <div className="caption">
        <i className="fa-solid fa-euro-sign"></i>
        {"14"}/hour
      </div>
    </div>
  );
};
