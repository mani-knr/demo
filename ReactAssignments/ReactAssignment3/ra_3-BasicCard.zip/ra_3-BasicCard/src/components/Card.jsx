import React from "react";
import { LowerCard } from "./LowerCard";
import { UpperCard } from "./UpperCard";

export const Card = () => {
  return (
    <div className="main-card">
      <UpperCard />
      <LowerCard />
    </div>
  );
};
