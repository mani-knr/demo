import React from "react";

export const LowerCard = () => {
  return (
    <div className="lower-card">
      <div>
        <h5>{"Jeffrey Abrams"}</h5>
        <div className="caption">
          <i class="fa-solid fa-location-dot"> </i> {"New York"},{" "}
          {"United States"}
        </div>
      </div>
      <div className="caption2">
        {"Abrams was born in New York City and raised in Los Angeles"}
      </div>
      <div className="buttons">
        <button className="outlined">VIEW CV</button>
        <button className="contained">MAKE OFFER</button>
      </div>
      <div className="status">
        <i className={"fa-solid fa-circle active"}></i>Online
      </div>
    </div>
  );
};
