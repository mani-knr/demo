import React from "react";
import { Example } from "./Carousel";

export const HomePage = () => {
	return (
		<div>
			<Example />
		</div>
	);
};
