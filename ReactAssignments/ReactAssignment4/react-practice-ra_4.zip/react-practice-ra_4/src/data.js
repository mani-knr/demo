let personsData = [
  {
    profile: "conor",
    role: "Fighter",
    skills: ["Left Hook", "Boxing", "Billionarie Strut"],
    name: "CONOR McGREGOR",
    city: "Dublin",
    country: "Ireland",
    intro:
      "Conor Anthony McGregor is an Irish professional mixed martial artist. ... McGregor's boxing is typically considered his best skill",
    status: "active",
  },
  {
    profile: "luffy",
    role: "Pirate",
    skills: ["Rubber Man", "Conquerer's Haki", "Advanced Haki"],
    name: "MONKEY.D.LUFFY",
    city: "Hidden Leaf Village",
    country: "Japan",
    intro:
      "Monkey D. Luffy, also known as 'Strawhat luffy', is the main protagonist of the manga and anime",
    status: "2023-03-17 12:30:00:000",
    premium: true,
  },
];

export { personsData };
