package main

import (
	"assignment2/greet"
	"fmt"
)

func main() {
	fmt.Println("Full name : ", greet.GetFormattedName())
}
