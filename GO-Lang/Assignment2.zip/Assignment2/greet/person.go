package greet

var FirstName = "Manikanta"
var LastName = "KNR"
