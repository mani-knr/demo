package greet

func GetFormattedName() string {
	return FirstName + " " + LastName
}
