package main

import (
	"fmt"
	"io"
	"net/http"
	"strings"
	"golang.org/x/net/html"
)

func main() {
	resp, err := http.Get("https://gradious.com/")
	if err != nil {
		panic(err)
	}
	defer resp.Body.Close()
	data, err := io.ReadAll(resp.Body)
	if err != nil {
		panic(err)
	}
	docTree, _ := html.Parse(strings.NewReader(string(data)))
	fmt.Println(extractText(docTree))
}
func extractText(n *html.Node) string {
	var result string
	if n == nil {
		return result
	}
	if n.Type == html.TextNode && n.Parent.Data != "script" && n.Parent.Data != "style" {
		return strings.TrimSpace(n.Data)
	}

	for c := n.FirstChild; c != nil; c = c.NextSibling {
		result += extractText(c)
	}
	return result
}
